from django.shortcuts import render


def home(request):
    return render(request, "gym/home.html", {"page": "home"})


def library(request):
    return render(request, "gym/placeholder.html", {"title": "Library", "page": "library"})


def gym_setup(request):
    return render(request, "gym/placeholder.html", {"title": "Gym", "page": "gym"})


def routines(request):
    return render(request, "gym/placeholder.html", {"title": "Routines", "page": "routines"})
